ecg_normal:正常状态
ecg_fear:害怕
ecg_happy:愉悦

采样频率:250Hz (每行代表1秒)

